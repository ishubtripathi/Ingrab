# Ingrab

Ingrab is a user-friendly application designed for downloading posts and reels from Instagram user profiles. This package allows you to easily access and save Instagram content for personal use, research, or archiving.

## Features

- Download images and videos (reels) from Instagram profiles.
- Support for downloading recent posts.
- Simple and intuitive command-line interface.

## Installation

To install and use Ingrab, follow these steps:

### Install the Package

You can install Ingrab directly from PyPI using pip:

```bash
pip install ingrab

